<div class="kopa-search-box">
    <form method="get" class="search-form clearfix" action="<?php echo esc_url(home_url('/')); ?>">
        <input type="text" class="search-text" name="s" placeholder="<?php esc_attr_e('Search...', 'upside-lite'); ?>">
        <button type="submit" class="search-submit"><i class="fa fa-search"></i></button>
    </form>
</div>

